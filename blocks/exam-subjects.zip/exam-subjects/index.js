document.addEventListener('DOMContentLoaded', function () {

    // Проверка что Gutenberg загрузился
    if (!window.wp || !window.wp.blocks) {
        console.error('WP blocks not loaded');
        return;
    }

    (function (blocks, blockEditor, element, components) {

        const el = element.createElement;
        const useBlockProps = blockEditor.useBlockProps;
        const TextControl = components.TextControl;
        const Button = components.Button;

        blocks.registerBlockType('groundwrk/exam-subjects', {

            edit: function (props) {
                const { attributes, setAttributes } = props;
                const items = attributes.items || [];

                function addItem() {
                    setAttributes({
                        items: [
                            ...items,
                            { title: '', percent: '', correct: '', color: 'green' }
                        ]
                    });
                }

                function updateItem(index, key, value) {
                    const newItems = items.map((item, i) => {
                        if (i === index) {
                            return {
                                ...item,
                                [key]: value
                            };
                        }
                        return item;
                    });

                    setAttributes({ items: newItems });
                }

                return el(
                    'div',
                    useBlockProps(),

                    items.map(function (item, index) {
                        return el(
                            'div',
                            {
                                key: index,
                                style: {
                                    border: '1px solid #ddd',
                                    padding: '10px',
                                    marginBottom: '10px'
                                }
                            },

                            el(TextControl, {
                                label: 'Title',
                                value: item.title,
                                onChange: (v) => updateItem(index, 'title', v)
                            }),

                            el(TextControl, {
                                label: 'Percent',
                                value: item.percent,
                                onChange: (v) => updateItem(index, 'percent', v)
                            }),

                            el(TextControl, {
                                label: 'Correct',
                                value: item.correct,
                                onChange: (v) => updateItem(index, 'correct', v)
                            }),

                            el(
                                'select',
                                {
                                    value: item.color || 'green',
                                    onChange: (e) =>
                                        updateItem(index, 'color', e.target.value),
                                    style: {
                                        marginTop: '8px',
                                        width: '100%'
                                    }
                                },

                                el('option', { value: 'green' }, 'Green'),
                                el('option', { value: 'yellow' }, 'Yellow (#ffbd47)'),
                                el('option', { value: 'red' }, 'Red (#ff4747)')
                            )
                        );
                    }),

                    el(
                        Button,
                        { variant: 'primary', onClick: addItem },
                        'Add Item'
                    )
                );
            },

            save: function (props) {
                const items = props.attributes.items || [];

                return el(
                    'div',
                    useBlockProps.save(),

                    el(
                        'div',
                        { className: 'exam__subjects-list' },

                        items.map(function (item, index) {

                            let colorClass = 'exam__subject-bar-inner-green';

                            if (item.color === 'yellow') {
                                colorClass = 'exam__subject-bar-inner-yellow';
                            }

                            if (item.color === 'red') {
                                colorClass = 'exam__subject-bar-inner-red';
                            }

                            return el(
                                'div',
                                { className: 'exam__subject', key: index },

                                el(
                                    'div',
                                    { className: 'exam__subject-top' },
                                    el('div', {}, item.title),
                                    el('div', {}, item.percent + '%')
                                ),

                                el(
                                    'div',
                                    { className: 'exam__subject-correct' },
                                    item.correct
                                ),

                                el(
                                    'div',
                                    { className: 'exam__subject-bar' },
                                    el('div', {
                                        className: 'exam__subject-bar-inner ' + colorClass,
                                        style: { width: item.percent + '%' }
                                    })
                                )
                            );
                        })
                    )
                );
            }

        });

    })(
        window.wp.blocks,
        window.wp.blockEditor || window.wp.editor,
        window.wp.element,
        window.wp.components
    );

});